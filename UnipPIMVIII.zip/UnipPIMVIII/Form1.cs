﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace UnipPIMVIII
{
    public partial class Form1 : Form
    {
        MySqlConnection conexao;
        MySqlCommand comando;
        MySqlDataAdapter da;
        MySqlDataReader dr;
        string strSQL;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server = localhost; Database = cad_cliente; Uid = root; Pwd = maturidade11;");



                strSQL = "INSERT INTO PESSOA (NOME, CPF, ENDEREÇO) VALUES (@NOME, @CPF, @ENDEREÇO); INSERT INTO ENDEREÇO (LOGRADOURO, NÚMERO, CEP, BAIRRO, CIDADE, ESTADO) VALUES (@LOGRADOURO, @NÚMERO, @CEP, @BAIRRO, @CIDADE, @ESTADO); INSERT INTO TELEFONE (TELEFONE, DDD, TIPO) VALUES (@TELEFONE, @DDD, @TIPO)";
                comando = new MySqlCommand(strSQL, conexao);

                comando.Parameters.AddWithValue("@NOME", txtNome.Text);
                comando.Parameters.AddWithValue("@CPF", txtCPF.Text);
                comando.Parameters.AddWithValue("@ENDEREÇO", txtEndereço.Text);

                comando.Parameters.AddWithValue("@LOGRADOURO", txtLogradouro.Text);
                comando.Parameters.AddWithValue("@NÚMERO", txtNúmero.Text);
                comando.Parameters.AddWithValue("@CEP", txtCEP.Text);
                comando.Parameters.AddWithValue("@BAIRRO", txtBairro.Text);
                comando.Parameters.AddWithValue("@CIDADE", txtCidade.Text);
                comando.Parameters.AddWithValue("@ESTADO", txtEstado.Text);

                comando.Parameters.AddWithValue("@TELEFONE", txtTelefone.Text);
                comando.Parameters.AddWithValue("@DDD", txtDDD.Text);
                comando.Parameters.AddWithValue("@TIPO", txtTipo.Text);


                conexao.Open();

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server = localhost; Database = cad_cliente; Uid = root; Pwd = maturidade11;");

                strSQL = "UPDATE PESSOA SET NOME = @NOME, CPF = @CPF, ENDEREÇO = @ENDEREÇO,  WHERE ID = @ID";

                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@NOME", txtNome.Text);
                comando.Parameters.AddWithValue("@CPF", txtCPF.Text);
                comando.Parameters.AddWithValue("@ENDEREÇO", txtEndereço.Text);
                comando.Parameters.AddWithValue("@ID", txtID.Text);



                conexao.Open();

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server = localhost; Database = cad_cliente; Uid = root; Pwd = maturidade11;");

                strSQL = "DELETE FROM PESSOA WHERE ID = @ID; DELETE FROM ENDEREÇO WHERE ID = @ID; DELETE FROM TELEFONE WHERE ID = @ID";

                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@ID", txtID.Text);
              

                conexao.Open();

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection("Server = localhost; Database = cad_cliente; Uid = root; Pwd = maturidade11;");

                strSQL = "SELECT * FROM PESSOA JOIN TELEFONE ON PESSOA.ID = TELEFONE.ID";
                //strSQL = "SELECT * FROM PESSOA WHERE ID = @ID AND ID = @ID";


                comando = new MySqlCommand(strSQL, conexao);
                comando.Parameters.AddWithValue("@ID", txtID.Text);


                conexao.Open();

                dr = comando.ExecuteReader();

                while (dr.Read())
                {
                    txtNome.Text = Convert.ToString(dr["Nome"]);
                    txtCPF.Text = Convert.ToString(dr["CPF"]);
                    txtEndereço.Text = Convert.ToString(dr["Endereço"]);


                    txtLogradouro.Text = Convert.ToString(dr["Logradouro"]);
                    txtNúmero.Text = Convert.ToString(dr["Número"]);
                    txtCEP.Text = Convert.ToString(dr["CEP"]);
                    txtBairro.Text = Convert.ToString(dr["Bairro"]);
                    txtCidade.Text = Convert.ToString(dr["Cidade"]);
                    txtEstado.Text = Convert.ToString(dr["Estado"]);


                    txtTelefone.Text = Convert.ToString(dr["Telefone"]);
                    txtDDD.Text = Convert.ToString(dr["DDD"]);
                    txtTipo.Text = Convert.ToString(dr["Tipo"]);


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexao.Close();
                conexao = null;
                comando = null;
            }
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
